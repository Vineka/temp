package com.cms.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.bean.AdminBean;
import com.cms.entity.AdminEntity;
import com.cms.exception.ApplicationException;

@Repository("adminDao")
public class AdminDaoImpl implements AdminDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public int addAdmin(AdminBean adminBean) throws ApplicationException {
		// TODO Auto-generated method stub
		int check = 0;

		try {
			AdminEntity adminEntity = new AdminEntity();
			adminEntity.setFirstName(adminBean.getFirstName());
			adminEntity.setLastName(adminBean.getLastName());
			adminEntity.setAge(adminBean.getAge());
			adminEntity.setGender(adminBean.getGender());
			adminEntity.setDob(adminBean.getDob());
			adminEntity.setContactNumber(adminBean.getContactNumber());
			adminEntity.setAltContactNumber(adminBean.getAltContactNumber());
			adminEntity.setEmailId(adminBean.getEmailId());
			adminEntity.setPassword(adminBean.getPassword());

			sessionFactory.getCurrentSession().saveOrUpdate(adminEntity);

			adminEntity = (AdminEntity) sessionFactory.getCurrentSession().get(AdminEntity.class,
					adminEntity.getAdminId());
			check = adminEntity.getAdminId();

		} catch (HibernateException addAdminExp) {
			ApplicationException addAppExp = new ApplicationException(-1, addAdminExp.getMessage());
			throw addAppExp;
		}
		return check;
	}

	@Override
	public AdminBean loginAdminCheck(int adminId) throws ApplicationException {
		// TODO Auto-generated method stub

		AdminEntity adminEntity = null;
		AdminBean adminBean = new AdminBean();

		try {
			List list = (List) sessionFactory.getCurrentSession()
					.createQuery("from AdminEntity where adminId='" + adminId + "'").list();

			if (list != null && list.size() > 0) {
				adminEntity = (AdminEntity) list.get(0);
				adminBean.setAdminId(adminEntity.getAdminId());
				adminBean.setFirstName(adminEntity.getFirstName());
				adminBean.setPassword(adminEntity.getPassword());
			} else {
				adminBean = null;
			}
		} catch (HibernateException loginExp) {
			ApplicationException loginAppExp = new ApplicationException(-1, loginExp.getMessage());
			throw loginAppExp;
		}

		return adminBean;
	}

	@Override
	public int adminPasswordUpdate(int adminId, String password) throws ApplicationException {
		// TODO Auto-generated method stub
		AdminEntity adminEntity = new AdminEntity();
		AdminEntity entity = null;
		int check;
		try {
			adminEntity.setAdminId(adminId);

			entity = (AdminEntity) sessionFactory.getCurrentSession().get(AdminEntity.class, adminEntity.getAdminId());

			if (entity != null) {
				entity.setPassword(password);
				sessionFactory.getCurrentSession().update(entity);
				check = 1;
			} else {
				check = 0;
			}

		} catch (HibernateException adminPassExp) {
			ApplicationException passAppExp = new ApplicationException(-1, adminPassExp.getMessage());
			throw passAppExp;
		}
		return check;
	}
}
