package com.cms.dao;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.bean.ContractBean;
import com.cms.entity.TermsAndConditionsEntity;
import com.cms.exception.ApplicationException;

@Repository("tacDao")
public class TermsAndConditionsDaoImpl implements TermsAndConditionsDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public int addTac(ContractBean contractBean) throws ApplicationException {
		// TODO Auto-generated method stub
		try {
			TermsAndConditionsEntity tacEntity = new TermsAndConditionsEntity();

			tacEntity.setCondition1(contractBean.getCondition1());
			tacEntity.setTerm1(contractBean.getTerm1());
			tacEntity.setCondition2(contractBean.getCondition2());
			tacEntity.setTerm2(contractBean.getTerm2());
			tacEntity.setCondition3(contractBean.getCondition3());
			tacEntity.setTerm3(contractBean.getTerm3());

			sessionFactory.getCurrentSession().saveOrUpdate(tacEntity);
		} catch (HibernateException addTacExp) {
			ApplicationException appExp = new ApplicationException(-1, addTacExp.getMessage());
			throw appExp;
		}
		return 1;
	}

	@Override
	public int updateTac(ContractBean contractBean) throws ApplicationException {
		// TODO Auto-generated method stub
		try {
			TermsAndConditionsEntity tacEntity2 = new TermsAndConditionsEntity();

			tacEntity2.setContractId(contractBean.getContractId());
			tacEntity2.setCondition1(contractBean.getCondition1());
			tacEntity2.setCondition2(contractBean.getCondition2());
			tacEntity2.setCondition3(contractBean.getCondition3());
			tacEntity2.setTerm1(contractBean.getTerm1());
			tacEntity2.setTerm2(contractBean.getTerm2());
			tacEntity2.setTerm3(contractBean.getTerm3());

			sessionFactory.getCurrentSession().update(tacEntity2);

		} catch (HibernateException updateTacExp) {
			ApplicationException appExp = new ApplicationException(-1, updateTacExp.getMessage());
			throw appExp;
		}
		return 1;
	}

}
