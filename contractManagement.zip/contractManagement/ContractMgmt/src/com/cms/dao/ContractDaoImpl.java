package com.cms.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.bean.ContractBean;
import com.cms.entity.AmenityEntity;
import com.cms.entity.ContractEntity;
import com.cms.entity.TermsAndConditionsEntity;
import com.cms.exception.ApplicationException;

@Repository("contractDao")
public class ContractDaoImpl implements ContractDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public int addContract(ContractBean contractBean) throws ApplicationException {

		int identifier = 0;

		try {
			ContractEntity contractEntity1 = new ContractEntity();

			contractEntity1.setContractDesc(contractBean.getContractDesc());
			contractEntity1.setContractProDate(contractBean.getContractProDate());
			contractEntity1.setContractSubDate(contractBean.getContractSubDate());
			contractEntity1.setContractStatus(contractBean.getContractStatus());
			contractEntity1.setSupplierId(contractBean.getSupplierId());

			sessionFactory.getCurrentSession().saveOrUpdate(contractEntity1);

			contractEntity1 = (ContractEntity) sessionFactory.getCurrentSession().get(ContractEntity.class,
					contractEntity1.getContractId());

			identifier = contractEntity1.getContractId();

		} catch (HibernateException addContractExp) {
			ApplicationException addConAppExp = new ApplicationException(-1, addContractExp.getMessage());
			throw addConAppExp;
		}
		return identifier;
	}

	@Override
	public List<ContractBean> listContract() throws ApplicationException {

		List<ContractBean> contractDetails = null;

		try {

			List list1 = sessionFactory.getCurrentSession().createQuery("from ContractEntity").list();
			List list2 = sessionFactory.getCurrentSession().createQuery("from TermsAndConditionsEntity").list();
			List list3 = sessionFactory.getCurrentSession().createQuery("from AmenityEntity").list();
			contractDetails = new ArrayList();

			for (int i = 0; i < list1.size(); i++) {

				ContractBean contractBean = new ContractBean();
				ContractEntity contractEntity = (ContractEntity) list1.get(i);
				TermsAndConditionsEntity tacEntity = (TermsAndConditionsEntity) list2.get(i);
				AmenityEntity amenityEntity = (AmenityEntity) list3.get(i);

				contractBean.setContractId(contractEntity.getContractId());
				contractBean.setContractDesc(contractEntity.getContractDesc());
				contractBean.setContractSubDate(contractEntity.getContractSubDate());
				contractBean.setContractProDate(contractEntity.getContractProDate());
				contractBean.setContractStatus(contractEntity.getContractStatus());
				contractBean.setSupplierId(contractEntity.getSupplierId());
				contractBean.setCondition1(tacEntity.getCondition1());
				contractBean.setCondition2(tacEntity.getCondition2());
				contractBean.setCondition3(tacEntity.getCondition3());
				contractBean.setTerm1(tacEntity.getTerm1());
				contractBean.setTerm2(tacEntity.getTerm2());
				contractBean.setTerm3(tacEntity.getTerm3());
				contractBean.setAmenity1(amenityEntity.getAmenity1());
				contractDetails.add(contractBean);
			}

		} catch (HibernateException listConExp) {
			ApplicationException listAppExp = new ApplicationException(-1, listConExp.getMessage());
			throw listAppExp;
		}
		return contractDetails;
	}

	@Override
	public ContractBean fetchContract(int contractId) throws ApplicationException {

		ContractBean contractBean5 = null;
		try {
			contractBean5 = new ContractBean();
			ContractEntity contractEntity = (ContractEntity) sessionFactory.getCurrentSession()
					.createQuery("from ContractEntity where contractId=" + contractId).list().get(0);
			TermsAndConditionsEntity tacEntity = (TermsAndConditionsEntity) sessionFactory.getCurrentSession()
					.createQuery("from TermsAndConditionsEntity where contractId=" + contractId).list().get(0);
			AmenityEntity amenityEntity = (AmenityEntity) sessionFactory.getCurrentSession()
					.createQuery("from AmenityEntity where contractId=" + contractId).list().get(0);

			contractBean5.setContractId(contractEntity.getContractId());
			contractBean5.setContractDesc(contractEntity.getContractDesc());
			contractBean5.setContractSubDate(contractEntity.getContractSubDate());
			contractBean5.setContractProDate(contractEntity.getContractProDate());
			contractBean5.setContractStatus(contractEntity.getContractStatus());
			contractBean5.setSupplierId(contractEntity.getSupplierId());
			contractBean5.setCondition1(tacEntity.getCondition1());
			contractBean5.setCondition2(tacEntity.getCondition2());
			contractBean5.setCondition3(tacEntity.getCondition3());
			contractBean5.setTerm1(tacEntity.getTerm1());
			contractBean5.setTerm2(tacEntity.getTerm2());
			contractBean5.setTerm3(tacEntity.getTerm3());
			contractBean5.setAmenity1(amenityEntity.getAmenity1());

		} catch (HibernateException fetchExp) {
			ApplicationException fetchAppExp = new ApplicationException(-1, fetchExp.getMessage());
			throw fetchAppExp;
		}
		return contractBean5;
	}

	@Override
	public int updateContract(ContractBean contractBean) throws ApplicationException {
		int identifier = 1;

		try {
			ContractEntity contractEntity = new ContractEntity();
			TermsAndConditionsEntity tacEntity = new TermsAndConditionsEntity();
			AmenityEntity amenityEntity = new AmenityEntity();

			contractEntity.setContractId(contractBean.getContractId());
			contractEntity.setContractDesc(contractBean.getContractDesc());
			contractEntity.setContractProDate(contractBean.getContractProDate());
			contractEntity.setContractSubDate(contractBean.getContractSubDate());
			contractEntity.setContractStatus(contractBean.getContractStatus());
			contractEntity.setSupplierId(contractBean.getSupplierId());
			tacEntity.setContractId(contractBean.getContractId());
			tacEntity.setCondition1(contractBean.getCondition1());
			tacEntity.setCondition2(contractBean.getCondition2());
			tacEntity.setCondition3(contractBean.getCondition3());
			tacEntity.setTerm1(contractBean.getTerm1());
			tacEntity.setTerm2(contractBean.getTerm2());
			tacEntity.setTerm3(contractBean.getTerm3());
			amenityEntity.setAmenity1(contractBean.getAmenity1());
			amenityEntity.setContractId(contractBean.getContractId());

			sessionFactory.getCurrentSession().update(contractEntity);
			sessionFactory.getCurrentSession().update(tacEntity);
			sessionFactory.getCurrentSession().update(amenityEntity);

		} catch (HibernateException updExp) {
			ApplicationException updAppExp = new ApplicationException(-1, updExp.getMessage());
			throw updAppExp;
		}
		return identifier;
	}

	@Override
	public int deleteContract(int contractId) throws ApplicationException {

		try {
			ContractEntity contractEntity1 = new ContractEntity();
			TermsAndConditionsEntity tacEntity1 = new TermsAndConditionsEntity();
			AmenityEntity amenityEntity1 = new AmenityEntity();

			contractEntity1.setContractId(contractId);
			tacEntity1.setContractId(contractId);
			amenityEntity1.setContractId(contractId);

			sessionFactory.getCurrentSession().delete(contractEntity1);
			sessionFactory.getCurrentSession().delete(tacEntity1);
			sessionFactory.getCurrentSession().delete(amenityEntity1);

		} catch (HibernateException delConExp) {
			ApplicationException delConAppExp = new ApplicationException(-1, delConExp.getMessage());
			throw delConAppExp;
		}
		return 1;
	}

	@Override
	public void updateContractStatus(ContractBean contractBean) throws ApplicationException {

		ContractEntity contractEntity = new ContractEntity();
		try {
			contractEntity.setContractId(contractBean.getContractId());
			ContractEntity entity = (ContractEntity) sessionFactory.getCurrentSession().get(ContractEntity.class,
					contractEntity.getContractId());
			entity.setContractStatus(contractBean.getContractStatus());
			sessionFactory.getCurrentSession().update(entity);

		} catch (HibernateException updStatusExp) {
			ApplicationException updAppExp = new ApplicationException(-1, updStatusExp.getMessage());
			throw updAppExp;
		}

	}

	@Override
	public List<ContractBean> fetchContractUsingStatus(String contractStatus) throws ApplicationException {

		List<ContractBean> contractDetails = null;
		try {
			List contractList = sessionFactory.getCurrentSession()
					.createQuery(
							"from ContractEntity where contractStatus='" + contractStatus + "' order by supplierId")
					.list();
			contractDetails = new ArrayList();

			for (int i = 0; i < contractList.size(); i++) {
				ContractBean contractBean = new ContractBean();
				ContractEntity contractEntity = (ContractEntity) contractList.get(i);

				contractBean.setSupplierId(contractEntity.getSupplierId());
				contractBean.setContractId(contractEntity.getContractId());
				contractBean.setContractDesc(contractEntity.getContractDesc());
				contractBean.setContractStatus(contractEntity.getContractStatus());

				contractDetails.add(contractBean);
			}
		} catch (HibernateException fetchConStaExp) {
			ApplicationException fetchConAppExp = new ApplicationException(-1, fetchConStaExp.getMessage());
			throw fetchConAppExp;
		}
		return contractDetails;
	}

	@Override
	public List<ContractBean> fetchAllContracts() throws ApplicationException {

		List<ContractBean> contractDetails3 = null;
		try {
			List contractList = sessionFactory.getCurrentSession()
					.createQuery("from ContractEntity order by supplierId").list();
			contractDetails3 = new ArrayList();

			for (int i = 0; i < contractList.size(); i++) {
				ContractBean contractBean2 = new ContractBean();
				ContractEntity contractEntity2 = (ContractEntity) contractList.get(i);

				contractBean2.setSupplierId(contractEntity2.getSupplierId());
				contractBean2.setContractId(contractEntity2.getContractId());
				contractBean2.setContractDesc(contractEntity2.getContractDesc());
				contractBean2.setContractStatus(contractEntity2.getContractStatus());

				contractDetails3.add(contractBean2);
			}
		} catch (HibernateException fetchAllExp) {
			ApplicationException fetchAllAppExp = new ApplicationException(-1, fetchAllExp.getMessage());
			throw fetchAllAppExp;
		}
		return contractDetails3;
	}

	@Override
	public ContractBean trackContractStatus(int contractId) throws ApplicationException {
		// TODO Auto-generated method stub

		ContractBean contractBean = new ContractBean();
		ContractEntity contractEntity = null;
		try {
			List list = (List) sessionFactory.getCurrentSession()
					.createQuery("from ContractEntity where contractId=" + contractId).list();

			if (list.size() > 0 && list != null) {
				contractEntity = (ContractEntity) list.get(0);
				contractBean.setContractId(contractEntity.getContractId());
				contractBean.setSupplierId(contractEntity.getSupplierId());
				contractBean.setContractStatus(contractEntity.getContractStatus());
			} else {
				contractBean = null;
			}

		} catch (HibernateException hiber) {
			ApplicationException trackConStaExp = new ApplicationException(-1, hiber.getMessage());
			throw trackConStaExp;
		}
		return contractBean;
	}

}
