package com.cms.controller;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cms.bean.ContractBean;
import com.cms.bean.SupplierBean;
import com.cms.exception.ApplicationException;
import com.cms.service.ContractService;
import com.cms.service.SupplierService;

@Controller
public class SupplierController {
	@Autowired
	SupplierService supplierService;

	@Autowired
	ContractService contractService;

	static Logger log = Logger.getLogger("ContractMgmt");

	@RequestMapping("/supplierLogin")
	public ModelAndView login(ModelMap map) {
		ModelAndView mav1 = null;
		map.addAttribute("command", new SupplierBean());
		mav1 = new ModelAndView("supplierLogin");
		return mav1;
	}

	@RequestMapping("/supplierRegister")
	public ModelAndView supplierRegister(ModelMap model) {
		ModelAndView modelAV = null;
		model.addAttribute("command", new SupplierBean());
		modelAV = new ModelAndView("addSupplier");
		return modelAV;
	}

	@RequestMapping(value = "/backButton", method = RequestMethod.POST)
	public ModelAndView creatContract(@ModelAttribute("command") SupplierBean supplierBean, ModelMap map) {
		ModelAndView modAV = null;
		map.addAttribute("contractBean", new ContractBean());
		modAV = new ModelAndView("supplierLogin");
		return modAV;
	}

	@RequestMapping(value = "/loginSupplier", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView loginSupplier(@Valid @ModelAttribute("command") SupplierBean supplierBean1,
			BindingResult loginError, HttpSession session) throws ParseException {
		ModelAndView mav2 = null;
		SupplierBean supplier = null;
		SupplierBean supplierBean = null;

		if (loginError.hasErrors() && supplierBean1.getPassword().equals("")) {
			mav2 = new ModelAndView("supplierLogin");
		} else {
			try {
				supplier = supplierService.loginSupplierCheck(supplierBean1.getSupplierId());

				if (supplier != null) {
					supplierBean = supplierService.checkDate(supplier);
					session.setAttribute("supplierBean", supplierBean);

					if (supplierBean1.getPassword().equals(supplierBean.getPassword())
							&& supplierBean1.getSupplierId() == supplierBean.getSupplierId()) {

						if (supplierBean.getSupplierStatus().equals("APPROVED")) {
							mav2 = new ModelAndView("supplier");
						} else if (supplierBean.getSupplierStatus().equals("REJECTED")) {
							mav2 = new ModelAndView("supplierLogin", "message", "Login denied by Admin");
						} else if (supplierBean.getSupplierStatus().equals("SUBMITTED")) {
							mav2 = new ModelAndView("supplierLogin", "message",
									"Wait for approval from Admin in order to login");
						}
					} else {
						mav2 = new ModelAndView("supplierLogin", "message", "Invalid Username or Password");
					}
				} else {
					mav2 = new ModelAndView("supplierLogin");
				}
			} catch (ApplicationException loginSupplierExp) {

				log.info(loginSupplierExp.getMessage());
				mav2 = new ModelAndView("applicationError");

			}
		}
		return mav2;
	}

	@RequestMapping(value = "/addSupplier", method = RequestMethod.POST)
	public ModelAndView saveSupplier(@Valid @ModelAttribute("command") SupplierBean supplierBean, BindingResult result1,
			HttpSession session) {
		ModelAndView mav3 = null;
		int identifier = 0;

		if (result1.hasErrors()) {
			mav3 = new ModelAndView("addSupplier");
		} else {
			try {

				identifier = supplierService.addSupplier(supplierBean);

				if (identifier != 0) {
					mav3 = new ModelAndView("supplierLogin", "successMessage",
							"Successfully registered. Use this ID: " + identifier + " to login.");
				} else {
					mav3 = new ModelAndView("error");
				}

			} catch (ApplicationException addSupplierExp) {

				log.info(addSupplierExp.getMessage());
				mav3 = new ModelAndView("applicationError");

			}
		}
		return mav3;
	}

	@RequestMapping("/logout")
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws IOException {

		session.invalidate();

		return new ModelAndView("about");
	}

	@RequestMapping("/fetchAllSuppliers")
	public ModelAndView fetchAllSuppliers(HttpServletRequest request, HttpSession session) {
		ModelAndView mav4 = null;
		if (session.getAttribute("adminBean") != null) {

			List<SupplierBean> supplierList = new ArrayList<SupplierBean>();

			try {
				supplierList = supplierService.fetchAllSuppliers();

				request.setAttribute("supplierList", supplierList);

				if (supplierList.size() != 0) {
					mav4 = new ModelAndView("manageSupplier", "supplierList", supplierList);
				} else {
					mav4 = new ModelAndView("manageSupplier", "recordMessage", "No Records Found");
				}

			} catch (ApplicationException fetchSuppExp) {

				log.info(fetchSuppExp.getMessage());
				mav4 = new ModelAndView("applicationError");

			}
		} else {
			mav4 = new ModelAndView("about");
		}
		return mav4;
	}

	@RequestMapping("/fetchSupplier")
	public ModelAndView fetchSupplier(@RequestParam("supplierStatus") String status, HttpSession session) {
		ModelAndView mav5 = null;
		if (session.getAttribute("adminBean") != null) {

			List<SupplierBean> supplierList2 = new ArrayList<SupplierBean>();

			try {

				supplierList2 = supplierService.fetchSupplier(status);

				if (supplierList2.size() != 0) {
					mav5 = new ModelAndView("manageSupplier", "supplierList", supplierList2);
				} else {
					mav5 = new ModelAndView("manageSupplier", "recordMessage", "No Records Found");
				}

			} catch (ApplicationException fetchSupplExp) {

				log.info(fetchSupplExp.getMessage());
				mav5 = new ModelAndView("applicationError");

			}

		} else {
			mav5 = new ModelAndView("about");
		}
		return mav5;
	}

	@RequestMapping("/updateSupplierStatus")
	public ModelAndView updateSupplierStatus(HttpServletRequest request1,
			@ModelAttribute("command") SupplierBean supplierBean, BindingResult error, HttpSession session) {
		ModelAndView mav6 = null;
		List<SupplierBean> supplierList1 = new ArrayList<SupplierBean>();

		if (session.getAttribute("adminBean") != null) {

			try {
				supplierService.updateSupplierStatus(supplierBean);
				supplierList1 = supplierService.fetchAllSuppliers();

				request1.setAttribute("supplierList", supplierList1);

				if (supplierList1.size() != 0) {
					mav6 = new ModelAndView("manageSupplier", "supplierList", supplierList1);
				} else {
					mav6 = new ModelAndView("manageSupplier", "recordMessage", "No Records Found");
				}

			} catch (ApplicationException updateSuppExp) {

				log.info(updateSuppExp.getMessage());
				mav6 = new ModelAndView("applicationError");

			}

			mav6 = new ModelAndView("manageSupplier");

		} else {
			mav6 = new ModelAndView("about");
		}
		return mav6;
	}

	@RequestMapping("/passwordUpdate")
	public ModelAndView passwordUpdate(@RequestParam("password1") String password, HttpServletRequest request,
			@ModelAttribute("command") SupplierBean supplierBean, BindingResult result, HttpSession session) {
		ModelAndView mav7 = null;
		int check = 0;
		try {
			if (supplierBean.getPassword().equals(password)) {
				check = supplierService.passwordUpdate(supplierBean.getSupplierId(), password);
				if (check == 1) {
					mav7 = new ModelAndView("supplierLogin", "message1",
							"Password Changed Successfully.Please Login Again!");
				} else {
					mav7 = new ModelAndView("updatePassword", "updateMessage", "No such ID found. Please Register");
				}
			} else {
				mav7 = new ModelAndView("updatePassword", "updateMessage", "Password Doesn't Match");
			}
		} catch (ApplicationException passwordUpdExp) {

			log.info(passwordUpdExp.getMessage());
			mav7 = new ModelAndView("applicationError");

		}

		return mav7;
	}

}
