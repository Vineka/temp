package com.cms.controller;

import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cms.bean.AdminBean;
import com.cms.exception.ApplicationException;
import com.cms.service.AdminService;
import com.cms.service.ContractService;
import com.cms.service.SupplierService;

@Controller
public class AdminController {

	@Autowired
	AdminService adminService;

	@Autowired
	SupplierService supplierService;

	@Autowired
	ContractService contractService;

	static Logger log = Logger.getLogger("ContractMgmt");

	@RequestMapping("/login")
	public ModelAndView login(ModelMap map) {
		ModelAndView mav;
		map.addAttribute("command", new AdminBean());
		mav = new ModelAndView("adminLogin");
		return mav;
	}

	@RequestMapping("/adminRegister")
	public ModelAndView adminRegister(ModelMap map) {
		ModelAndView mandv;
		map.addAttribute("command", new AdminBean());
		mandv = new ModelAndView("addAdmin");
		return mandv;
	}

	@RequestMapping(value = "/addAdmin", method = RequestMethod.POST)
	public ModelAndView saveAdmin(@ModelAttribute("command") @Validated AdminBean adminBean, BindingResult result,
			HttpSession session) {
		ModelAndView mav8;
		int identifier;

		if (result.hasErrors()) {
			mav8 = new ModelAndView("addAdmin");

		} else {
			try {

				identifier = adminService.addAdmin(adminBean);
				mav8 = new ModelAndView("adminLogin", "successMessage1",
						"Successfully registered. Use this ID: " + identifier + " to login.");

			} catch (ApplicationException ae) {

				log.info(ae.getMessage());
				mav8 = new ModelAndView("applicationError");

			}
		}
		return mav8;
	}

	@RequestMapping(value = "/loginAdmin", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView loginAdmin(@ModelAttribute("command") @Validated AdminBean adminBean1, BindingResult result,
			HttpSession session) {
		ModelAndView mav9;

		if (result.hasErrors() && adminBean1.getPassword().equals("")) {
			mav9 = new ModelAndView("adminLogin");
		} else {
			try {
				AdminBean adminBean = null;
				adminBean = adminService.loginAdminCheck(adminBean1.getAdminId());

				if (adminBean != null) {
					session.setAttribute("adminBean", adminBean);

					if (adminBean1.getPassword().equals(adminBean.getPassword())
							&& adminBean1.getAdminId() == (adminBean.getAdminId())) {

						mav9 = new ModelAndView("admin");
					} else {
						mav9 = new ModelAndView("adminLogin", "message1", "Invalid Username or Password");
					}
				} else {
					mav9 = new ModelAndView("adminLogin", "message1", "Invalid Username or Password");
				}

			} catch (ApplicationException applicationExp) {

				log.info(applicationExp.getMessage());
				mav9 = new ModelAndView("applicationError");
			}
		}
		return mav9;
	}

	@RequestMapping("/adminPasswordUpdate")
	public ModelAndView adminPasswordUpdate(@RequestParam("password1") String password, HttpServletRequest request,
			@ModelAttribute("command") AdminBean adminBean, BindingResult result, HttpSession session) {
		ModelAndView mAndV;
		int initial;
		try {
			if (adminBean.getPassword().equals(password)) {
				initial = adminService.adminPasswordUpdate(adminBean.getAdminId(), password);
				if (initial == 1) {
					mAndV = new ModelAndView("adminLogin", "message1",
							"Password Changed Successfully.Please Login Again!");
				} else {
					mAndV = new ModelAndView("updatePasswordAdmin", "updateMessage",
							"No such Id found. Please Register");
				}

			} else {
				mAndV = new ModelAndView("updatePasswordAdmin", "updateMessage", "Password Doesn't Match");
			}

		} catch (ApplicationException appExp) {

			log.info(appExp.getMessage());
			mAndV = new ModelAndView("applicationError");

		}

		return mAndV;
	}

}
