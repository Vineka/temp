package com.cms.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cms.bean.ContractBean;
import com.cms.bean.SupplierBean;
import com.cms.exception.ApplicationException;
import com.cms.service.AmenityService;
import com.cms.service.ContractService;
import com.cms.service.SupplierService;
import com.cms.service.TermsAndConditionsService;

@Controller
public class ContractController {

	@Autowired
	ContractService contractService;

	@Autowired
	TermsAndConditionsService tacService;

	@Autowired
	AmenityService amenityService;

	@Autowired
	SupplierService supplierService;

	static Logger log = Logger.getLogger("ContractMgmt");

	@RequestMapping(value = "/createContract", method = RequestMethod.POST)
	public ModelAndView creatContract(@ModelAttribute("command") ContractBean ContractBean,
			@RequestParam("supplierId") int supplierId, ModelMap map) {
		ModelAndView maview = null;
		map.addAttribute("contractBean", new ContractBean());

		maview = new ModelAndView("createContract", "supplierId", supplierId);
		return maview;
	}

	@RequestMapping(value = "/addContract", method = RequestMethod.GET)
	public ModelAndView addContract(@RequestParam("supplierId") int supplierId,
			@Valid @ModelAttribute("command") ContractBean contractBean, BindingResult result, HttpSession session) {

		ModelAndView maview1 = null;

		if (result.hasErrors()) {
			maview1 = new ModelAndView("createContract");
		} else {
			if (session.getAttribute("supplierBean") != null && contractBean != null) {

				List<ContractBean> contractList = new ArrayList<ContractBean>();
				List<ContractBean> contractList1 = new ArrayList<ContractBean>();
				int identifier = 0;

				try {

					identifier = contractService.addContract(contractBean);
					tacService.addTac(contractBean);
					amenityService.addAmenity(contractBean);
					contractList = contractService.listContract();

					for (ContractBean contract : contractList) {
						if (contract.getSupplierId() == supplierId) {
							contractList1.add(contract);
						}
					}
					Map<String, Object> model = new HashMap<String, Object>();
					model.put("contractList", contractList1);
					model.put("addMessage", "Contract created successfully");

					if (identifier != 0) {
						maview1 = new ModelAndView("supplier", model);
					} else {
						maview1 = new ModelAndView("error");
					}

				} catch (ApplicationException addContractExp) {

					log.info(addContractExp.getMessage());
					maview1 = new ModelAndView("applicationError");

				}

			} else {
				maview1 = new ModelAndView("about");
			}
		}
		return maview1;
	}

	@RequestMapping(value = "/fetchContract", method = RequestMethod.GET)
	public ModelAndView fetchContract(@RequestParam("contractId") int contractId, HttpSession session, ModelMap map) {
		ModelAndView maview2 = null;

		if (session.getAttribute("supplierBean") != null) {

			ContractBean contractBean = new ContractBean();
			try {

				contractBean = contractService.fetchContract(contractId);

				if (contractBean != null) {
					map.addAttribute("command", new ContractBean());
					maview2 = new ModelAndView("editContract", "contractBean", contractBean);
				} else {
					maview2 = new ModelAndView("error");
				}

			} catch (ApplicationException fetchContractExp) {

				log.info(fetchContractExp.getMessage());
				maview2 = new ModelAndView("applicationError");

			}
		} else {
			maview2 = new ModelAndView("about");
		}
		return maview2;
	}

	@RequestMapping(value = "/trackContractStatus", method = RequestMethod.GET)
	public ModelAndView trackContractStatus(@ModelAttribute("command") ContractBean contractBean1, BindingResult result,
			HttpSession session) {

		ModelAndView maview3 = null;

		ContractBean contractBean = new ContractBean();
		if (session.getAttribute("supplierBean") != null) {
			try {
				contractBean = contractService.trackContractStatus(contractBean1.getContractId());

				if (contractBean != null) {
					if (contractBean1.getSupplierId() == contractBean.getSupplierId()) {
						maview3 = new ModelAndView("trackContract", "contractBean", contractBean);
					} else {
						maview3 = new ModelAndView("trackContract", "message1",
								"No Contract Found for Id " + contractBean1.getContractId());
					}
				} else {
					maview3 = new ModelAndView("trackContract", "message1",
							"No Contract Found for Id " + contractBean1.getContractId());
				}
			} catch (ApplicationException trackStatusExp) {

				log.info(trackStatusExp.getMessage());
				maview3 = new ModelAndView("applicationError");

			}
		} else {
			maview3 = new ModelAndView("about");
		}
		return maview3;
	}

	@RequestMapping(value = "/updateContract", method = RequestMethod.GET)
	public ModelAndView updateContract(@RequestParam("supplierId") int supId,
			@Valid @ModelAttribute("command") ContractBean contractBean1, BindingResult result, HttpSession session) {

		ModelAndView modview4 = null;

		if (result.hasErrors()) {
			modview4 = new ModelAndView("editContract");
		} else {
			if (session.getAttribute("supplierBean") != null) {

				List<ContractBean> contractList, contractList1 = new ArrayList<ContractBean>();

				int initial = 0;

				try {
					initial = contractService.updateContract(contractBean1);
					tacService.updateTac(contractBean1);
					amenityService.updateAmenity(contractBean1);

					contractList = contractService.listContract();

					for (ContractBean contract : contractList) {
						if (contract.getSupplierId() == supId) {
							contractList1.add(contract);
						}
					}

					Map<String, Object> mod1 = new HashMap<String, Object>();
					mod1.put("contractList", contractList1);
					mod1.put("editMessage", "Contract updated successfully");

					if (initial != 0) {
						modview4 = new ModelAndView("supplier", mod1);
					} else {
						modview4 = new ModelAndView("error");
					}

				} catch (ApplicationException updateContractExp) {

					log.info(updateContractExp.getMessage());
					modview4 = new ModelAndView("applicationError");

				}

			} else {
				modview4 = new ModelAndView("about");
			}
		}
		return modview4;
	}

	@RequestMapping(value = "/deleteContract", method = RequestMethod.GET)
	public ModelAndView deleteContract(@RequestParam("contractId") int contractId,
			@RequestParam("supplierId") int supplierId, HttpSession session) {

		ModelAndView maview5 = null;

		if (session.getAttribute("supplierBean") != null) {

			List<ContractBean> contractList3, contractList1 = new ArrayList<ContractBean>();
			int start = 0;

			try {
				if (session.getAttribute("supplierBean") == null) {
					maview5 = new ModelAndView("about");
				}

				start = contractService.deleteContract(contractId);
				contractList3 = contractService.listContract();

				for (ContractBean contract : contractList3) {
					if (contract.getSupplierId() == supplierId) {
						contractList1.add(contract);
					}
				}

				if (start != 0) {
					if (contractList1.size() != 0) {
						maview5 = new ModelAndView("supplier", "contractList", contractList1);
					} else {
						maview5 = new ModelAndView("supplier", "recordMessage", "No Records Found");
					}
				} else {
					maview5 = new ModelAndView("error");
				}

			} catch (ApplicationException deleteContractExp) {

				log.info(deleteContractExp.getMessage());
				maview5 = new ModelAndView("applicationError");

			}
		} else {
			maview5 = new ModelAndView("about");
		}
		return maview5;
	}

	@RequestMapping("/viewContract")
	public ModelAndView viewContract(@RequestParam("supplierId") int supId, HttpSession session) {
		ModelAndView maview6 = null;
		if (session.getAttribute("supplierBean") != null) {

			SupplierBean supplierBean = new SupplierBean();
			List<ContractBean> contractList3, contractList1 = new ArrayList<ContractBean>();

			try {
				contractList3 = contractService.listContract();

				for (ContractBean contract : contractList3) {
					if (contract.getSupplierId() == supId) {
						contractList1.add(contract);
					}
				}

				supplierBean = supplierService.fetchSupplier(supId);
				session.setAttribute("supplierBean", supplierBean);

				if (contractList1.size() != 0) {
					maview6 = new ModelAndView("supplier", "contractList", contractList1);
				} else {
					maview6 = new ModelAndView("supplier", "recordMessage", "No Records Found");
				}

			} catch (ApplicationException viewContractExp) {

				log.info(viewContractExp.getMessage());
				maview6 = new ModelAndView("applicationError");

			}

		} else {
			maview6 = new ModelAndView("about");
		}
		return maview6;

	}

	@RequestMapping("/updateContractStatus")
	public ModelAndView updateContractStatus(@ModelAttribute("command") ContractBean contractBean, BindingResult result,
			HttpSession session) {

		ModelAndView maview7 = null;

		if (session.getAttribute("adminBean") != null) {

			List<ContractBean> contractList = new ArrayList<ContractBean>();
			Map<String, Object> model = new HashMap<String, Object>();

			try {
				contractService.updateContractStatus(contractBean);
				contractList = contractService.fetchAllContracts();

				model.put("contractList", contractList);

			} catch (ApplicationException updateStatusExp) {

				log.info(updateStatusExp.getMessage());
				maview7 = new ModelAndView("applicationError");

			}
			maview7 = new ModelAndView("manageContract", model);

		} else {
			maview7 = new ModelAndView("about");
		}
		return maview7;
	}

	@RequestMapping("/fetchContractUsingStatus")
	public ModelAndView fetchContractUsingStatus(@RequestParam("contractStatus") String contractStatus,
			HttpSession session) {
		ModelAndView maview8 = null;
		if (session.getAttribute("adminBean") != null) {

			List<ContractBean> contractList1 = new ArrayList<ContractBean>();
			try {
				contractList1 = contractService.fetchContractUsingStatus(contractStatus);

				if (contractList1.size() != 0) {
					maview8 = new ModelAndView("manageContract", "contractList", contractList1);
				} else {
					maview8 = new ModelAndView("manageContract", "recordMessage", "No Records Found");
				}

			} catch (ApplicationException fetchStatusExp) {

				log.info(fetchStatusExp.getMessage());
				maview8 = new ModelAndView("applicationError");

			}
		} else {
			maview8 = new ModelAndView("about");
		}
		return maview8;
	}

	@RequestMapping("/fetchContractForAdmin")
	public ModelAndView fetchContractForAdmin(HttpSession session) throws ApplicationException {

		ModelAndView maview9 = null;

		if (session.getAttribute("adminBean") != null) {

			List<ContractBean> contractBean = new ArrayList<ContractBean>();

			try {

				contractBean = contractService.listContract();

				if (contractBean.size() != 0) {
					maview9 = new ModelAndView("manageContract", "contractList", contractBean);
				} else {
					maview9 = new ModelAndView("manageContract", "recordMessage", "No Records Found");
				}

			} catch (ApplicationException fetchAdminExp) {

				log.info(fetchAdminExp.getMessage());
				maview9 = new ModelAndView("applicationError");

			}

		} else {
			maview9 = new ModelAndView("about");
		}

		return maview9;
	}
}
