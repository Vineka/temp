package com.cms.service;

import com.cms.bean.AdminBean;
import com.cms.exception.ApplicationException;

public interface AdminService {

	public int addAdmin(AdminBean adminBean) throws ApplicationException;

	public int adminPasswordUpdate(int adminId, String password) throws ApplicationException;

	public AdminBean loginAdminCheck(int adminId) throws ApplicationException;
}
