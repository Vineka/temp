package com.cms.service;

import java.text.ParseException;
import java.util.List;

import org.springframework.context.annotation.ComponentScan;

import com.cms.bean.SupplierBean;
import com.cms.exception.ApplicationException;

@ComponentScan
public interface SupplierService {

	public SupplierBean loginSupplierCheck(int supplierId) throws ApplicationException;

	public int passwordUpdate(int supplierId, String password) throws ApplicationException;

	public SupplierBean fetchSupplier(int supplierId) throws ApplicationException;

	public List<SupplierBean> fetchAllSuppliers() throws ApplicationException;

	public SupplierBean checkDate(SupplierBean supplierBean) throws ApplicationException, ParseException;

	public int addSupplier(SupplierBean supplierBean) throws ApplicationException;

	public List<SupplierBean> fetchSupplier(String status) throws ApplicationException;

	public void updateSupplierStatus(SupplierBean supplierBean) throws ApplicationException;
}
