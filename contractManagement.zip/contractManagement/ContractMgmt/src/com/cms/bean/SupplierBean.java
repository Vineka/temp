package com.cms.bean;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

public class SupplierBean {
	@NotEmpty(message = "Please Enter Contact Number")
	@Pattern(regexp = "^[0-9]+$", message = "Contact Number should  not contain alphabets")
	@Length(min = 10, max = 10)
	private String contactNumber;

	@NotEmpty(message = "Please Enter email")
	@Email(message = "Please enter valid email")
	private String emailId;

	@NotEmpty
	@Size(min = 5, max = 17)
	@Pattern(regexp = "^[A-Za-z]+$", message = "FirstName should not contain numbers")
	private String firstName;

	@NotEmpty(message = "Please Enter Gender")
	private String gender;

	@Length(min = 10, max = 10)
	@Pattern(regexp = "^[0-9]+$", message = "Contact Number should  not contain alphabets")
	private String altContactNumber;

	@NotNull(message = "Please Enter Supplier Id")
	private int supplierId;

	@Range(min = 18, max = 45)
	private int age;
	private String addressLine2;

	@NotEmpty
	@Pattern(regexp = "^[A-Za-z]+$", message = "LastName should not contain numbers")
	private String lastName;

	@NotEmpty(message = "State should not be empty")
	private String state;

	@NotEmpty(message = "Please Enter Password")
	private String password;
	@NotEmpty(message = "City should not be empty")
	@Pattern(regexp = "^[0-9]+$", message = "Zipcode should not contain Alphabets")
	@Length(min = 6, max = 6)
	private String zipCode;

	private String supplierStatus;
	private String creationDate;
	@NotEmpty(message = "City should not be empty")
	private String city;

	@NotEmpty(message = "Please Enter DoB")
	private String dob;

	@NotEmpty(message = "AddressLine1 should be between 30 to 50 characters")
	private String addressLine1;

	public String getSupplierStatus() {
		return supplierStatus;
	}

	public void setSupplierStatus(String supplierStatus) {
		this.supplierStatus = supplierStatus;
	}

	public int getSupplierId() {
		return supplierId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public int getAge() {
		return age;
	}

	public void setAltContactNumber(String altContactNumber) {
		this.altContactNumber = altContactNumber;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getGender() {
		return gender;
	}

	public String getDob() {
		return dob;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPassword() {
		return password;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getAltContactNumber() {
		return altContactNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

}
