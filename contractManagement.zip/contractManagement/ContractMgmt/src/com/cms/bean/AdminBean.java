package com.cms.bean;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

public class AdminBean {

	@NotNull(message = "Please enter id")
	private int adminId;

	@NotEmpty
	@Pattern(regexp = "^[A-Za-z]+$", message = "LastName should not contain numbers")
	private String lastName;

	@NotEmpty
	@Pattern(regexp = "^[A-Za-z]+$", message = "FirstName should not contain numbers")
	@Size(min = 5, max = 17)
	private String firstName;
	
	@Range(min = 18, max = 45)
	private int age;

	@NotEmpty(message = "Please Enter Gender")
	private String gender;

	@NotEmpty(message = "Please Enter DoB")
	private String dob;

	@Pattern(regexp = "^[0-9]+$", message = "Contact Number should  not contain alphabets")
	@Length(min = 10, max = 10)
	private String altContactNumber;

	@NotEmpty(message = "Please Enter email")
	@Email(message = "Please enter valid email")
	private String emailId;

	@NotEmpty(message = "Please Enter Password")
	private String password;

	@NotEmpty(message = "Please Enter Contact Number")
	@Length(min = 10, max = 10)
	@Pattern(regexp = "^[0-9]+$", message = "Contact Number should  not contain alphabets")
	private String contactNumber;

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getAltContactNumber() {
		return altContactNumber;
	}

	public void setAltContactNumber(String altContactNumber) {
		this.altContactNumber = altContactNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "AdminBean [adminId=" + adminId + ", firstName=" + firstName + ", lastName=" + lastName + ", age=" + age
				+ ", gender=" + gender + ", dob=" + dob + ", contactNumber=" + contactNumber + ", altContactNumber="
				+ altContactNumber + ", emailId=" + emailId + ", password=" + password + "]";
	}

}
