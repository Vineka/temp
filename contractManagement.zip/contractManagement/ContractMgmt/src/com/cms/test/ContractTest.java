package com.cms.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import static org.junit.Assert.*;

import java.util.*;

import com.cms.bean.ContractBean;
import com.cms.exception.ApplicationException;
import com.cms.service.AmenityService;
import com.cms.service.ContractService;
import com.cms.service.TermsAndConditionsService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="file:**//WEB-INF/cms-servlet.xml")
public class ContractTest {

	ContractBean contractBean = new ContractBean();

	@Autowired
	ContractService contractService;

	@Autowired
	TermsAndConditionsService tacService;

	@Autowired
	AmenityService amenityService;

	/*@Test
	public void addContractTest() throws ApplicationException {

		int contractId = 0;

		contractBean.setContractDesc("New Contract ");
		contractBean.setContractProDate("18 Jun 2019");
		contractBean.setContractSubDate("24 Jun 2019");
		contractBean.setContractStatus("SUBMITTED");
		contractBean.setSupplierId(5);

		contractId = contractService.addContract(contractBean);
		assertNotNull("Successfully Tested", contractId);

	}*/

	@Test
	public void listContractTest() throws ApplicationException {
		List<ContractBean> contractList = new ArrayList<ContractBean>();
		contractList = contractService.listContract();
		assertEquals("Successfully Tested", 5, contractList.size());
	}

	@Test
	public void fetchContractTest() throws ApplicationException {
		contractBean.setContractId(5);
		contractBean = contractService.fetchContract(contractBean.getContractId());
		assertEquals("Successfully Tested", "SUBMITTED", contractBean.getContractStatus());
	}

	@Test
	public void fetchContractUsingStatusTest() throws ApplicationException {
		List<ContractBean> contractList = new ArrayList<ContractBean>();
		contractBean.setContractStatus("APPROVED");
		contractList = contractService.fetchContractUsingStatus(contractBean.getContractStatus());
		assertEquals("Successfully Tested", 1, contractList.size());
	}

	@Test
	public void fetchAllContractsTest() throws ApplicationException {
		List<ContractBean> contractList = new ArrayList<ContractBean>();
		contractList = contractService.fetchAllContracts();
		assertEquals("Successfully Tested", 5 , contractList.size());
	}

	@Test
	public void tractContractStatusTest() throws ApplicationException {
		contractBean.setContractId(8);
		contractBean = contractService.trackContractStatus(contractBean.getContractId());
		assertEquals("Successfully Tested", "SUBMITTED", contractBean.getContractStatus());
	}

	/*@Test
	public void deleteContractTest() throws ApplicationException {
		contractBean.setContractId(8);
		int check = contractService.deleteContract(contractBean.getContractId());
		assertEquals("Successfully Tested", 1, check);
	}*/

}
