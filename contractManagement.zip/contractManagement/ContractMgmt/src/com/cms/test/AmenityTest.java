package com.cms.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import static org.junit.Assert.*;
import com.cms.bean.ContractBean;
import com.cms.exception.ApplicationException;
import com.cms.service.AmenityService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="file:**//WEB-INF/cms-servlet.xml")
public class AmenityTest {

	ContractBean contractBean = new ContractBean();

	@Autowired
	AmenityService amenityService;

	@Test
	public void addAmenityTest() throws ApplicationException {
		int check;
		contractBean.setAmenity1("Good");
		check = amenityService.addAmenity(contractBean);
		assertEquals("Successfully Tested", 1, check);
	}
}
