package com.cms.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import static org.junit.Assert.*;
import com.cms.bean.ContractBean;
import com.cms.exception.ApplicationException;
import com.cms.service.TermsAndConditionsService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="file:**//WEB-INF/cms-servlet.xml")
public class TermsAndConditionsTest {

	ContractBean contractBean = new ContractBean();

	@Autowired
	TermsAndConditionsService amenityService;

	@Test
	public void addTermsAndConditionsTest() throws ApplicationException {
		

		contractBean.setCondition1("safety is important");
		contractBean.setTerm1("SAFETY");
		contractBean.setCondition2("Maintenance should be needed");
		contractBean.setTerm2("MAINTENANCE");
		contractBean.setCondition3("One Month");
		contractBean.setTerm3("TIMELINE");

		int check = amenityService.addTac(contractBean);

		assertEquals("Successfully Tested", 1, check);
	}
}
