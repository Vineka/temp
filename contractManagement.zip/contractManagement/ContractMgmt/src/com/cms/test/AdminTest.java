package com.cms.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.*;

import com.cms.bean.AdminBean;
import com.cms.exception.ApplicationException;
import com.cms.service.AdminService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="file:**//WEB-INF/cms-servlet.xml")
public class AdminTest {

	AdminBean adminBean = new AdminBean();

	@Autowired(required = true)
	AdminService adminService;

	@Test
	public void loginTest() throws ApplicationException {

			adminBean.setAdminId(5);
			adminBean = adminService.loginAdminCheck(adminBean.getAdminId());
			assertEquals("Successfully Tested", "12345", adminBean.getPassword());
	}

	/*@Test
	public void addAdmin() throws ApplicationException {

		adminBean.setFirstName("Murugan");
		adminBean.setLastName("Palani");
		adminBean.setAge(28);
		adminBean.setGender("male");
		adminBean.setDob("24 Jul 1990");
		adminBean.setContactNumber("8412536079");
		adminBean.setAltContactNumber("9658102347");
		adminBean.setEmailId("p@gmail.com");
		adminBean.setPassword("muruga");
		int adminId =  adminService.addAdmin(adminBean);
		assertNotNull("Successfully Tested", adminId);
	}*/
}
