package com.cms.test;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import static org.junit.Assert.*;

import java.util.*;

import com.cms.bean.SupplierBean;
import com.cms.exception.ApplicationException;
import com.cms.service.SupplierService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="file:**//WEB-INF/cms-servlet.xml")
public class SupplierTest {

	
	SupplierBean supplierBean = new SupplierBean();
		
	@Autowired
	SupplierService supplierService;
	
	@Test
	public void loginTest() throws ApplicationException{
		supplierBean.setSupplierId(5);
		supplierBean = supplierService.loginSupplierCheck(supplierBean.getSupplierId());
		assertEquals("Successfully Tested","123",supplierBean.getPassword());
	}
	
	/*@Test
	public void addSupplierTest() throws ApplicationException{
		int supplierId = 0;
		
		supplierBean.setFirstName("ManiKandan");
		supplierBean.setLastName("ManiKandan");
		supplierBean.setAge(27);
		supplierBean.setGender("male");
		supplierBean.setAddressLine1("Valluvar Colony");
		supplierBean.setAddressLine2("Merina Beach");
		supplierBean.setCity("Chennai");
		supplierBean.setState("TamilNadu");
		supplierBean.setContactNumber("9510236478");
		supplierBean.setAltContactNumber("8574962013");
		supplierBean.setCreationDate("18 Jun 2019");
		supplierBean.setDob("22 Jul 1990");
		supplierBean.setEmailId("m@gmail.com");
		supplierBean.setPassword("mani");
		supplierBean.setSupplierStatus("SUBMITTED");
		supplierBean.setZipCode("613560");
		
		supplierId = supplierService.addSupplier(supplierBean);
		assertNotNull("Successfully Tested",supplierId);
	}*/
	
	@Test
	public void fetchSupplierTest() throws ApplicationException{
		supplierBean.setSupplierId(4);
		supplierBean = supplierService.fetchSupplier(supplierBean.getSupplierId());
		assertEquals("Successfully Tested","TEST",supplierBean.getFirstName());
	}
	
	@Test
	public void fetchSupplierStatusTest() throws ApplicationException{
		List<SupplierBean> supplierList  = new ArrayList<SupplierBean>();
		supplierBean.setSupplierStatus("REJECTED");
		supplierList = supplierService.fetchSupplier(supplierBean.getSupplierStatus());
		assertEquals("Successfully Tested",4,supplierList.size());
	}
	
	@Test
	public void fetchAllSuppliersTest() throws ApplicationException{
		List<SupplierBean> supplierList  = new ArrayList<SupplierBean>();
		supplierList = supplierService.fetchAllSuppliers();
		assertEquals("Successfully Tested",8,supplierList.size());
	}
	
	
}
