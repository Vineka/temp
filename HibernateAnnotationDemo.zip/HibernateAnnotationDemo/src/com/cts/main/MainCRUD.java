package com.cts.main;
import java.util.List;
import org.hibernate.SessionFactory;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.cts.bean.Student_Detail;
/**
 * @author 761139
 *
 */
/**
 * @author 761139
 *
 */
public class MainCRUD {

	public static void main(String[] args) {
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
		SessionFactory factory = meta.getSessionFactoryBuilder().build();
		Session session = factory.openSession();
		//insert
	/*	Transaction t = session.beginTransaction();
		Student_Detail sd = new Student_Detail();
		sd.setId(50);
		sd.setStudent_name("Vidhya1");
		sd.setDept("ECE");
		sd.setYear(2019);
		session.persist(sd);
		t.commit();
		System.out.println("1 Record Inserted Successfully!!!");
		
		//update
		Transaction t1 = session.beginTransaction();
		Student_Detail sd1 = new Student_Detail();
		sd1.setId(55);
		sd1.setStudent_name("Vimala");
		sd1.setDept("EEE");
		sd1.setYear(2011);
		session.update(sd1);
		t1.commit();
		System.out.println("updated")*/
		
		//delete 
		/*Transaction t2 = session.beginTransaction();
		Student_Detail sd = (Student_Detail)session.load(Student_Detail.class, 50);
		sd.getStudName();
		sd.getDept();
		sd.getStudId();
		sd.getYop();
		session.delete(sd);
		t2.commit();
		System.out.println("Deleted");*/
		//read
		Transaction t1 = session.beginTransaction();
		List<Student_Detail> s1 = session.createNamedQuery("Student_Detail.findAll", Student_Detail.class).getResultList();
		for(Student_Detail sd1 : s1) {
			System.out.println(sd1.getStudId()+"\t"+sd1.getStudName()+"\t"+sd1.getDept()+"\t"+	sd1.getYop());
		}
		t1.commit();
		session.close();
		factory.close();
	}
}
