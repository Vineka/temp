package com.cts.bean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import javax.persistence.NamedQuery;

@Entity
@NamedQuery(name="Student_Detail.findAll",query="SELECT S FROM Student_Detail S")
public class Student_Detail {	
	@Id
	@Column(name="id")
	private int StudId;
	@Column(name="student_name")
	private String StudName;
	@Column(name="dept")
	private String Dept;
	@Column(name="year")
	private int yop;
	public int getStudId() {
		return StudId;
	}
	public void setStudId(int studId) {
		StudId = studId;
	}
	public String getStudName() {
		return StudName;
	}
	public void setStudName(String studName) {
		StudName = studName;
	}
	public String getDept() {
		return Dept;
	}
	public void setDept(String dept) {
		Dept = dept;
	}
	public int getYop() {
		return yop;
	}
	public void setYop(int yop) {
		this.yop = yop;
	}
	 
	
}
